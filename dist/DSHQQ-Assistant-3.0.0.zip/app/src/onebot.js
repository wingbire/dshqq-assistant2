import { oneLine, normalizeName } from "./untrusted.js";

// OneBot v11 群消息接入。P1：只用群消息；私聊/通知/请求一律忽略。
// 传输层可注入（transport），所以单测不需要真开 WebSocket。
// Node 24 自带全局 WebSocket，不引入任何依赖。

export const ONEBOT_DEFAULT = {
  reconnectMs: 3000,
  maxBackoffMs: 60000,
  dedupeWindowMs: 180000,
  maxTextLen: 300
};

export function withToken(url, token) {
  const u = String(url || "");
  if (!token) return u;
  if (/[?&]access_token=/.test(u)) return u;
  return u + (u.includes("?") ? "&" : "?") + "access_token=" + encodeURIComponent(String(token));
}

// OneBot v11 原始事件 → 内部事件。返回 null 表示「不该处理的」。
export function normalizeEvent(raw, ctx) {
  const c = ctx || {};
  if (!raw || typeof raw !== "object") return null;
  if (raw.post_type === "meta_event") {
    if (raw.meta_event_type === "lifecycle" && raw.self_id != null && c.onSelfId) c.onSelfId(String(raw.self_id));
    return null;
  }
  if (raw.post_type !== "message") return null;
  if (raw.message_type !== "group") return null;
  const selfId = String(c.selfId != null ? c.selfId : raw.self_id != null ? raw.self_id : "");
  const uid = String(raw.user_id != null ? raw.user_id : "");
  if (selfId && uid === selfId) return null;                  // 自己的消息不回

  const segs = Array.isArray(raw.message) ? raw.message : [];
  let atBot = false, atAll = false, replyToBot = false, replyToOther = false;
  const texts = [];
  for (const s of segs) {
    if (!s || typeof s !== "object") continue;
    const d = s.data || {};
    if (s.type === "text") texts.push(String(d.text || ""));
    else if (s.type === "at") {
      const qq = String(d.qq);
      if (qq === "all") atAll = true;
      else if (qq === selfId) atBot = true;
    } else if (s.type === "reply") {
      const id = String(d.id);
      if (c.sentIds && c.sentIds.has(id)) replyToBot = true; else replyToOther = true;
    }
  }
  // 图片 / 语音 / 视频也算「有内容」—— 纯图片消息不能因为没文字就被丢掉（N18 识图要用）
  const images = [];
  let hasRich = false;
  for (const s of segs) {
    if (!s || typeof s !== "object") continue;
    if (s.type === "image") { hasRich = true; images.push({ file: String((s.data || {}).file || ""), url: String((s.data || {}).url || "") }); }
    else if (s.type === "record" || s.type === "video" || s.type === "face" || s.type === "file") hasRich = true;
  }
  let text = texts.join("").trim();
  if (!text && typeof raw.raw_message === "string") text = raw.raw_message.replace(/\[CQ:(at|image|record|face),[^\]]*\]/g, "").trim();
  if (!text && !hasRich) return null;

  const sender = raw.sender || {};
  const speaker = normalizeName(sender.card || sender.nickname || uid);
  return {
    gid: String(raw.group_id),
    uid: uid,
    selfId: selfId,
    speaker: speaker,
    text: oneLine(text, c.maxTextLen || ONEBOT_DEFAULT.maxTextLen),
    raw: text,
    atBot: atBot,
    atAll: atAll,
    replyToBot: replyToBot,
    replyToOther: replyToOther,
    messageId: raw.message_id != null ? String(raw.message_id) : null,
    role: String(sender.role || ""),
    segments: segs,
    images: images,
    hasImage: images.length > 0,
    now: c.now != null ? c.now : Date.now()
  };
}

export function createOneBot(opts) {
  const o = opts || {};
  const cfg = Object.assign({}, ONEBOT_DEFAULT, o.config || {});
  const nowFn = o.now || function () { return Date.now(); };
  const transport = o.transport || function (url, t) {
    const W = typeof globalThis.WebSocket !== "undefined" ? globalThis.WebSocket : null;
    if (!W) throw new Error("运行时不带 WebSocket，请注入 transport");
    return new W(url, t);
  };
  const sentIds = new Set();
  const seen = new Map();
  const pendingActions = new Map();      // echo -> { resolve, timer }  —— 异步动作（get_status / get_group_list …）
  let selfId = o.selfId ? String(o.selfId) : null;
  let ws = null, stopped = false, retry = 0, timer = null;
  let state = "idle";

  function setState(s, extra) {
    state = s;
    if (o.onStatus) { try { o.onStatus(Object.assign({ state: s, selfId: selfId }, extra || {})); } catch (e) {} }
  }

  function remember(id) {
    if (id == null) return;
    sentIds.add(String(id));
    if (sentIds.size > 500) sentIds.delete(sentIds.values().next().value);
  }

  function dedupe(messageId) {
    if (messageId == null) return false;
    const key = String(messageId);
    const t = nowFn();
    const prev = seen.has(key);          // 注意：时间戳可能是 0，不能用取值真假来判断
    seen.set(key, t);
    for (const [k, v] of Array.from(seen.entries())) if (t - v > cfg.dedupeWindowMs) seen.delete(k);
    return prev;
  }

  function handlePayload(payload) {
    const data = typeof payload === "string" ? safeJson(payload) : payload;
    if (!data) return;
    if (data.echo != null && data.retcode != null) {          // 动作回执
      const p = pendingActions.get(String(data.echo));
      if (p) {
        clearTimeout(p.timer);
        pendingActions.delete(String(data.echo));
        p.resolve({ ok: data.status === "ok" || data.retcode === 0, status: data.status, retcode: data.retcode, data: data.data, echo: data.echo });
      }
      if (o.onAction) { try { o.onAction(data); } catch (e) {} }
      if (data.data && data.data.message_id != null) remember(data.data.message_id);
      return;
    }
    if (data.post_type) {
      const evt = normalizeEvent(data, {
        selfId: selfId, sentIds: sentIds, now: nowFn(), maxTextLen: cfg.maxTextLen,
        onSelfId: function (id) { selfId = id; }
      });
      if (!evt) return;
      if (evt.messageId && dedupe(evt.messageId)) return;
      if (o.onEvent) { try { o.onEvent(evt); } catch (e) {} }
    }
  }

  function connect() {
    if (stopped) return;
    setState(retry === 0 ? "connecting" : "reconnecting", { retry: retry });
    let sock = null;
    try { sock = transport(withToken(o.url, o.token), o.transportOptions || {}); } catch (e) {
      setState("error", { error: String(e && e.message) });
      return scheduleRetry();
    }
    ws = sock;
    sock.onopen = function () { retry = 0; setState("open"); if (o.onOpen) { try { o.onOpen(); } catch (e) {} } };
    sock.onmessage = function (m) { handlePayload(m && m.data !== undefined ? m.data : m); };
    sock.onclose = function () { if (!stopped) { setState("closed"); scheduleRetry(); } };
    sock.onerror = function (e) { setState("error", { error: String((e && e.message) || e) }); };
    return sock;
  }

  function scheduleRetry() {
    if (stopped) return null;
    retry += 1;
    const wait = Math.min(cfg.maxBackoffMs, cfg.reconnectMs * Math.pow(2, Math.min(retry - 1, 6)));
    timer = setTimeout(function () { connect(); }, wait);
    if (timer && timer.unref) timer.unref();
    return wait;
  }

  function send(payload) {
    if (!ws || typeof ws.send !== "function") return false;
    try { ws.send(typeof payload === "string" ? payload : JSON.stringify(payload)); return true; } catch (e) { return false; }
  }

  // 发送正文；N6 的多条发送由上层 split 后逐条调用本函数。
  function sendGroupMsg(gid, text) {
    const echo = "dshqq-" + nowFn() + "-" + Math.floor(Math.random() * 1e6);
    return send({ action: "send_group_msg", params: { group_id: Number(gid), message: String(text) }, echo: echo });
  }

  // 发图：OneBot v11 的 image 段。NapCat 认绝对路径（统一成正斜杠更稳）
  function sendGroupImage(gid, file) {
    if (!file) return false;
    const echo = "dshqq-img-" + nowFn() + "-" + Math.floor(Math.random() * 1e6);
    const p = String(file).replace(/\\/g, "/");
    return send({ action: "send_group_msg", params: { group_id: Number(gid), message: [{ type: "image", data: { file: p } }] }, echo: echo });
  }

  // 发语音（OneBot v11 的 record 段）。NapCat 认本地绝对路径或 base64://
  function sendGroupRecord(gid, file) {
    if (!file) return false;
    const echo = "dshqq-rec-" + nowFn() + "-" + Math.floor(Math.random() * 1e6);
    const p = String(file).replace(/\\/g, "/");
    return send({ action: "send_group_msg", params: { group_id: Number(gid), message: [{ type: "record", data: { file: p } }] }, echo: echo });
  }

  // 通用动作调用（不等回执，取图片、取群成员等）
  function callAction(action, params) {
    const echo = "dshqq-act-" + nowFn() + "-" + Math.floor(Math.random() * 1e6);
    send({ action: action, params: params || {}, echo: echo });
    return echo;
  }

  // 等回执的动作调用 —— 配置端读 OneBot/NapCat 状态、群列表都靠它
  function callActionAsync(action, params, timeoutMs) {
    return new Promise(function (resolve) {
      if (!ws || typeof ws.send !== "function") return resolve({ ok: false, error: "未连接 OneBot" });
      const echo = "dshqq-rq-" + nowFn() + "-" + Math.floor(Math.random() * 1e6);
      const timer = setTimeout(function () {
        pendingActions.delete(echo);
        resolve({ ok: false, error: "动作超时：" + action, timeout: true });
      }, timeoutMs || 8000);
      pendingActions.set(echo, { resolve: resolve, timer: timer });
      const sentOk = send({ action: action, params: params || {}, echo: echo });
      if (!sentOk) { clearTimeout(timer); pendingActions.delete(echo); resolve({ ok: false, error: "发送失败" }); }
    });
  }

  function close() {
    stopped = true;
    for (const [echo, p] of Array.from(pendingActions.entries())) { clearTimeout(p.timer); p.resolve({ ok: false, error: "连接已关闭" }); pendingActions.delete(echo); }
    if (timer) clearTimeout(timer);
    setState("stopped");
    try { if (ws && ws.close) ws.close(); } catch (e) {}
  }

  return {
    connect: connect, close: close, send: send, sendGroupMsg: sendGroupMsg, sendGroupImage: sendGroupImage,
    sendGroupRecord: sendGroupRecord, callAction: callAction, callActionAsync: callActionAsync,
    pendingActions: function () { return pendingActions.size; },
    state: function () { return state; }, selfId: function () { return selfId; },
    sentIds: sentIds, seenCount: function () { return seen.size; },
    config: cfg
  };
}

function safeJson(s) { try { return JSON.parse(s); } catch (e) { return null; } }
